<?php
// Allow cross-origin requests
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Handle OPTIONS pre-flight request (for CORS)
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Database connection details
$servername = "localhost";
$username = "root";
$password = ""; // Ensure this matches your MySQL server's root password
$dbname = "final"; // Ensure the database name matches

// Create a database connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Database connection failed: " . $conn->connect_error]);
    exit;
}

// Set headers for JSON responses
header('Content-Type: application/json');

// Get the requested endpoint
$request_method = $_SERVER["REQUEST_METHOD"];
$endpoint = $_GET['endpoint'] ?? '';

switch ($endpoint) {
    case "sensor-values":
        handleSensorValues($conn);
        break;
    case "ldr-data":
        handleLDRData($conn); // Fetch the last 15 LDR readings
        break;
    case "start-fan":
        controlFan($conn, true);  // Start the fan (relay on)
        break;
    case "stop-fan":
        controlFan($conn, false); // Stop the fan (relay off)
        break;
    case "save-node":
        saveNode($conn); // Save a new node to the database
        break;
    case "check-node":
        checkNode($conn); // Check if a node exists
        break;
    case "save-sensor-data":
        saveSensorData($conn); // Save sensor data
        break;
    case "settings":
        getSettings($conn); // Get the current configuration settings
        break;
    case "save-settings":
        saveSettings($conn); // Save configuration settings
        break;
    default:
        http_response_code(404);
        echo json_encode(["status" => "error", "message" => "Invalid endpoint"]);
}

// Handle GET requests for fetching sensor values
function handleSensorValues($conn) {
    // Query to get the most recent values for each sensor type
    $sql = "
        SELECT SensorType, SensorValue, Timestamp
        FROM sensordata
        WHERE (SensorType, Timestamp) IN (
            SELECT SensorType, MAX(Timestamp)
            FROM sensordata
            GROUP BY SensorType
        )
    ";
    $result = $conn->query($sql);

    if ($result === false) {
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Query failed: " . $conn->error]);
        return;
    }

    $sensorData = [];
    while ($row = $result->fetch_assoc()) {
        $sensorData[$row['SensorType']] = [
            "SensorValue" => $row['SensorValue'],
            "Timestamp" => $row['Timestamp']
        ];
    }

    if (!empty($sensorData)) {
        echo json_encode([
            "status" => "success",
            "data" => $sensorData
        ]);
    } else {
        http_response_code(404);
        echo json_encode(["status" => "error", "message" => "No sensor data found"]);
    }

    $result->free();
}


// Control the Fan (Relay)
function controlFan($conn, $status) {
    $fanStatus = $status ? 'ON' : 'OFF';
    echo json_encode(["status" => "success", "message" => "Fan turned $fanStatus"]);
}

function handleLDRData($conn) {
    $deviceId = isset($_GET['device_id']) ? $_GET['device_id'] : ''; // Get the device ID from the query parameter
    if (empty($deviceId)) {
        http_response_code(400);
        echo json_encode(["status" => "error", "message" => "Device ID is required"]);
        return;
    }

    $sql = "SELECT Timestamp, SensorValue AS ldrValue
            FROM sensordata
            WHERE NodeID = ? AND SensorType = 'Light'
            ORDER BY Timestamp DESC LIMIT 15";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param('s', $deviceId); // Bind the device ID to the query
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result === false) {
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Query failed: " . $conn->error]);
        return;
    }

    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }

    echo json_encode(["status" => "success", "data" => $data]);
}


// Save a new node
function saveNode($conn) {
    $data = json_decode(file_get_contents('php://input'), true);

    if (!isset($data['NodeID'], $data['NodeName'], $data['NodeLocation'])) {
        echo json_encode(["status" => "error", "message" => "Missing required fields"]);
        return;
    }

    // Update the SQL query to bind NodeID as string
    $sql = "INSERT INTO smartnodes (NodeID, NodeName, NodeLocation) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);

    // Bind NodeID as string ('s'), NodeName as string ('s'), NodeLocation as string ('s')
    $stmt->bind_param("sss", $data['NodeID'], $data['NodeName'], $data['NodeLocation']);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Node added successfully"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to add node"]);
    }

    $stmt->close();
}

// Check if a node exists
function checkNode($conn) {
    $nodeId = $_GET['nodeId'] ?? null;

    if ($nodeId) {
        $sql = "SELECT COUNT(*) as count FROM smartnodes WHERE NodeID = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $nodeId); // Binding as string ('s')
        $stmt->execute();
        $stmt->bind_result($count);
        $stmt->fetch();

        if ($count > 0) {
            echo json_encode(["status" => "success", "message" => "Node exists", "exists" => true]);
        } else {
            echo json_encode(["status" => "error", "message" => "Node does not exist", "exists" => false]);
        }

        $stmt->close();
    } else {
        echo json_encode(["status" => "error", "message" => "Missing NodeID"]);
    }
}

// Save sensor data
function saveSensorData($conn) {
    $data = json_decode(file_get_contents('php://input'), true);

    if (!isset($data['NodeID'], $data['SensorValue'], $data['SensorType'])) {
        echo json_encode(["status" => "error", "message" => "Missing required fields"]);
        return;
    }

    $sql = "INSERT INTO sensordata (NodeID, SensorValue, SensorType) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sds", $data['NodeID'], $data['SensorValue'], $data['SensorType']);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Sensor data saved successfully"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to save sensor data"]);
    }

    $stmt->close();
}

// Get configuration settings (GET)
function getSettings($conn) {
    $sql = "SELECT * FROM settings WHERE id = 1"; // Assuming one row for the configuration
    $result = $conn->query($sql);

    if ($result === false) {
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Query failed: " . $conn->error]);
        return;
    }

    if ($row = $result->fetch_assoc()) {
        echo json_encode([
            "status" => "success",
            "data" => [
                "protocol" => $row['protocol']
            ]
        ]);
    } else {
        echo json_encode(["status" => "error", "message" => "Settings not found"]);
    }

    $result->free();
}

// Save configuration settings (POST)
function saveSettings($conn) {
    $data = json_decode(file_get_contents('php://input'), true);

    if (!isset($data['protocol'])) {
        echo json_encode(["status" => "error", "message" => "Missing protocol"]);
        return;
    }

    $sql = "UPDATE settings SET protocol = ? WHERE id = 1"; // Assuming one row for the configuration
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $data['protocol']);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Settings saved successfully"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to save settings"]);
    }

    $stmt->close();
}

$conn->close();
?>