import mysql.connector
import paho.mqtt.client as mqtt
import json
from datetime import datetime

# MySQL Database connection setup
db_connection = mysql.connector.connect(
    host="localhost",  # IP address or hostname of your MySQL server
    user="root",  # Your MySQL username
    password="",  # Your MySQL password
    database="final"  # The database name
)
cursor = db_connection.cursor()

# MQTT Callback functions
def on_connect(client, userdata, flags, rc):
    print("Connected to broker with result code", rc)
    client.subscribe("smartnode/#")  # Subscribe to all topics under "smartnode"

def on_message(client, userdata, msg):
    try:
        # Parse the MQTT message payload
        payload = json.loads(msg.payload.decode())
        node_id = payload["NodeID"]  # Extract NodeID from the payload
        label = msg.topic.split("/")[-1]  # Extract the label from the topic
        value = payload.get(label)  # Get the sensor value 

        if value is None:
            print(f"Invalid data for label: {label}")
            return

        # Get the current timestamp
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Insert data into the Data table
        cursor.execute("""
            INSERT INTO sensordata(NodeID, Timestamp, SensorValue, SensorType)
            VALUES (%s, %s, %s, %s)
        """, (node_id, timestamp, value, label))
        db_connection.commit()
        print(f"Data saved: NodeID={node_id}, {label}={value}")

    except Exception as e:
        print("Error processing message:", e)

# MQTT Client setup
client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message

# Connect to the MQTT broker
client.connect("192.168.242.86", 1883, 60)  # Replace with your MQTT broker's IP
client.loop_forever()
