import mysql.connector
import paho.mqtt.client as mqtt
import json
from datetime import datetime

# MySQL Database connection setup
db_connection = mysql.connector.connect(
    host="localhost",  
    user="root",       
    password="",       
    database="final"  
)
cursor = db_connection.cursor()

# MQTT Callback functions
def on_connect(client, userdata, flags, rc):
    print("Connected to broker with result code", rc)
    client.subscribe("iot/sensors")  

def on_message(client, userdata, msg):
    try:
        # Parse the MQTT message payload
        payload = json.loads(msg.payload.decode())
        node_id = payload.get("NodeID")  # Extract NodeID from the payload
        sensor_type = payload.get("SensorType")  # Extract sensor type
        sensor_value = payload.get("SensorValue")  # Extract sensor value

        if not node_id or not sensor_type or sensor_value is None:
            print("Invalid data format:", payload)
            return

        # Get the current timestamp
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Insert data into the sensordata table
        cursor.execute("""
            INSERT INTO sensordata(NodeID, Timestamp, SensorValue, SensorType)
            VALUES (%s, %s, %s, %s)
        """, (node_id, timestamp, sensor_value, sensor_type))
        db_connection.commit()
        print(f"Data saved: NodeID={node_id}, {sensor_type}={sensor_value}")

    except Exception as e:
        print("Error processing message:", e)

# MQTT Client setup
client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message

# Connect to the MQTT broker
client.connect("172.20.10.2", 1883, 60)  # Replace with your MQTT broker's IP
client.loop_forever()
