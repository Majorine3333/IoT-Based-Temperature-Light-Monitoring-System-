document.getElementById('add-node-form').addEventListener('submit', async (event) => {
    event.preventDefault();

    // Get the form values
    const nodeID = document.getElementById('node-id').value.trim();
    const nodeName = document.getElementById('node-name').value.trim();
    const nodeLocation = document.getElementById('node-location').value.trim();

    // Validate input fields (nodeID, nodeName, and nodeLocation)
    if (!nodeID || !nodeName || !nodeLocation) {
        alert("All fields are required!");
        return;
    }

    // Prepare the data payload
    const payload = JSON.stringify({
        NodeID: nodeID,           // Add the unique identifier
        NodeName: nodeName,
        NodeLocation: nodeLocation
    });

    try {
        // Make the POST request to the save-node endpoint
        const response = await fetch('http://localhost/FINAL_IOT_PROJECT/smartdevice.php?endpoint=save-node', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: payload,
        });

        // Check if the response is successful
        if (!response.ok) {
            throw new Error("Network response was not ok");
        }

        // Check if the response is valid JSON
        const responseText = await response.text(); // Get raw response text
        let result;
        try {
            result = JSON.parse(responseText); // Try parsing as JSON
        } catch (jsonError) {
            console.error("Failed to parse JSON:", jsonError);
            console.error("Response content:", responseText);
            alert("Server returned an invalid response. Please try again later.");
            return;
        }

        // Handle the response based on the status
        if (result.status === "success") {
            alert("Node added successfully!");
            // Optionally, clear the form
            document.getElementById('add-node-form').reset();
        } else {
            alert(result.message || "Error adding node.");
        }
    } catch (error) {
        console.error("Failed to add node:", error);
        alert("Error adding node. Please try again.");
    }
});
